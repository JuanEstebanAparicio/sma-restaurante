
package sma.restaurante.agent;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.FIPANames;

import sma.restaurante.service.ReservaService;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AtenderSolicitudesACL extends CyclicBehaviour {

    private static final Logger LOG =
            Logger.getLogger(AtenderSolicitudesACL.class.getName());

    private static final String ONTOLOGIA = "Restaurante";

    private static final String PROTOCOLO =
            FIPANames.InteractionProtocol.FIPA_REQUEST;

    // Formato esperado: (reservar 101)
    private static final Pattern PATRON_RESERVAR = Pattern.compile(
            "^\\(\\s*reservar\\s+(\\d+)\\s*\\)$",
            Pattern.CASE_INSENSITIVE
    );

    // Obtiene el primer nombre de ingrediente del JSON devuelto por PostgreSQL.
    private static final Pattern PATRON_INGREDIENTE = Pattern.compile(
            "\"nombre\"\\s*:\\s*\"([^\"]+)\"",
            Pattern.CASE_INSENSITIVE
    );

    private final MessageTemplate plantilla;
    private final ReservaService reservaService;

    public AtenderSolicitudesACL(
            Agent agente,
            ReservaService reservaService
    ) {
        super(agente);

        this.reservaService = Objects.requireNonNull(
                reservaService,
                "El ReservaService no puede ser null"
        );

        plantilla = MessageTemplate.and(
                MessageTemplate.MatchProtocol(PROTOCOLO),
                MessageTemplate.MatchPerformative(ACLMessage.REQUEST)
        );
    }

    @Override
    public void action() {

        ACLMessage solicitud = myAgent.receive(plantilla);

        if (solicitud == null) {
            block();
            return;
        }

        procesarSolicitud(solicitud);
    }

    private void procesarSolicitud(ACLMessage solicitud) {

        // 1. Validar ontología.
        if (!ONTOLOGIA.equals(solicitud.getOntology())) {

            responder(
                    solicitud,
                    ACLMessage.NOT_UNDERSTOOD,
                    "(ontologia_no_soportada)"
            );

            return;
        }

        // 2. Validar emisor.
        if (solicitud.getSender() == null) {

            responder(
                    solicitud,
                    ACLMessage.NOT_UNDERSTOOD,
                    "(emisor_no_identificado)"
            );

            return;
        }

        // 3. Validar contenido.
        String contenido = solicitud.getContent();

        if (contenido == null || contenido.trim().isEmpty()) {

            responder(
                    solicitud,
                    ACLMessage.NOT_UNDERSTOOD,
                    "(contenido_vacio)"
            );

            return;
        }

        Matcher matcher = PATRON_RESERVAR.matcher(contenido.trim());

        if (!matcher.matches()) {

            responder(
                    solicitud,
                    ACLMessage.NOT_UNDERSTOOD,
                    "(formato_no_reconocido)"
            );

            LOG.warning("Contenido ACL no reconocido: " + contenido);

            return;
        }

        // 4. Obtener el identificador del pedido.
        Long idPedido;

        try {

            idPedido = Long.parseLong(matcher.group(1));

            if (idPedido <= 0) {
                throw new NumberFormatException();
            }

        } catch (NumberFormatException e) {

            responder(
                    solicitud,
                    ACLMessage.NOT_UNDERSTOOD,
                    "(id_pedido_invalido)"
            );

            return;
        }

        LOG.info(
                "Solicitud de reserva recibida. Pedido: "
                        + idPedido
                        + ". Emisor: "
                        + solicitud.getSender().getLocalName()
        );

        // 5. Informar que la solicitud será procesada.
        responder(
                solicitud,
                ACLMessage.AGREE,
                "(procesando_reserva " + idPedido + ")"
        );

        // 6. Ejecutar la reserva real en PostgreSQL.
        ejecutarReserva(solicitud, idPedido);
    }

    private void ejecutarReserva(
            ACLMessage solicitud,
            Long idPedido
    ) {

        try {

            ReservaService.ResultadoReserva resultado =
                    reservaService.reservarPedido(idPedido);

            if (resultado == null) {
                throw new IllegalStateException(
                        "El servicio de reserva devolvió un resultado null"
                );
            }

            // 7. Reserva exitosa.
            if (resultado.exito()) {

                responder(
                        solicitud,
                        ACLMessage.INFORM,
                        "(reserva_exitosa " + idPedido + ")"
                );

                LOG.info(
                        "Reserva completada correctamente para el pedido "
                                + idPedido
                );

                return;
            }

            // 8. Determinar el motivo del rechazo.
            String estado = resultado.estado();
            String ingrediente = "ingrediente_no_identificado";

            if ("RECHAZADO".equalsIgnoreCase(estado)) {

                ingrediente = obtenerIngredienteFaltante(
                        resultado.ingredientesFaltantesJson()
                );

                responder(
                        solicitud,
                        ACLMessage.REFUSE,
                        "(sin_existencia "
                                + idPedido
                                + " "
                                + ingrediente
                                + ")"
                );

                LOG.warning(
                        "Reserva rechazada por falta de existencias. "
                                + "Pedido: " + idPedido
                                + ". Ingrediente: " + ingrediente
                );

            } else {

                responder(
                        solicitud,
                        ACLMessage.REFUSE,
                        "(reserva_rechazada " + idPedido + ")"
                );

                LOG.warning(
                        "La base de datos rechazó la reserva. "
                                + "Pedido: " + idPedido
                                + ". Estado: " + estado
                                + ". Motivo: " + resultado.mensaje()
                );
            }

        } catch (RuntimeException e) {

            // 9. Error interno, SQL o conexión.
            LOG.log(
                    Level.SEVERE,
                    "Error al reservar los ingredientes del pedido "
                            + idPedido,
                    e
            );

            responder(
                    solicitud,
                    ACLMessage.FAILURE,
                    "(error_reserva " + idPedido + ")"
            );
        }
    }

    private String obtenerIngredienteFaltante(String json) {

        if (json == null || json.isBlank()) {
            return "ingrediente_no_identificado";
        }

        Matcher matcher = PATRON_INGREDIENTE.matcher(json);

        if (!matcher.find()) {
            return "ingrediente_no_identificado";
        }

        String nombre = matcher.group(1).trim();

        if (nombre.isEmpty()) {
            return "ingrediente_no_identificado";
        }

        // El contenido ACL utiliza un solo token para el ingrediente.
        return nombre
                .toLowerCase()
                .replaceAll("\\s+", "_");
    }

    private void responder(
            ACLMessage solicitud,
            int performativa,
            String contenido
    ) {

        ACLMessage respuesta = solicitud.createReply();

        respuesta.setProtocol(PROTOCOLO);
        respuesta.setOntology(ONTOLOGIA);
        respuesta.setPerformative(performativa);
        respuesta.setContent(contenido);

        myAgent.send(respuesta);

        LOG.info(
                "Respuesta ACL enviada: "
                        + ACLMessage.getPerformative(performativa)
                        + " | Contenido: "
                        + contenido
        );
    }
}
